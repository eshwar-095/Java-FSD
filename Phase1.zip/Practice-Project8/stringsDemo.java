package Practice;

public class stringsDemo {
	public static void main(String[]args) {
		System.out.println("Methods od String");
		String a = new String("Virat");
		String b = new String("Kholi");
		System.out.println(a);
		System.out.println(a.length());
		System.out.println(a.substring(2));
		System.out.println(a.concat(b));
		System.out.println(a.compareTo(b));
		System.out.println(b.isEmpty());
		System.out.println(b.toUpperCase());
		System.out.println(a.toLowerCase());
		System.out.println(a.replace('t', 'd'));
		System.out.println(a.equals(b));
		
		System.out.println("\n");
		System.out.println("Using StringBuffer");
		StringBuffer d = new StringBuffer();
		d= new StringBuffer("Rohit");
		d.append(" Sharma");
		System.out.println(d);
		System.out.println(d.charAt(4));
		System.out.println(d.length());
		System.out.println(d.indexOf("S"));
		System.out.println(d.substring(3));
		
		System.out.println("\n");
		System.out.println("Using StringBuilder");
		StringBuilder e = new StringBuilder();
		e= new StringBuilder("Rohit");
		e.append(" Sharma");
		System.out.println(e);
		System.out.println(e.charAt(4));
		System.out.println(e.length());
		System.out.println(e.indexOf("S"));
		System.out.println(e.substring(3));
		
	}
}
