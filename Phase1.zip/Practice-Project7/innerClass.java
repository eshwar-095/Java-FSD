package Practice;

public class innerClass {
	private String a ="Hello There!";
	
	class Inner{
		void display(){
			System.out.println(a +" I am Xyz ");}
		}
		public static void main(String[]agrs) {
			innerClass b = new innerClass();
			innerClass.Inner c= b.new Inner();
			c.display();
		
	}
}
