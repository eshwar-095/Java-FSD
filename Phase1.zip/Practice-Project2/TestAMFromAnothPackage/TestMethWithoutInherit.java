package TestAMFromAnothPackage;

import AccessModifiers.AccessModifier;

public class TestMethWithoutInherit {
	public static void main(String[]args) {
		AccessModifier obj= new  AccessModifier();
		obj.methodPublic();
		//obj.methodDefault();
		//obj.methodPrivate();
		//obj.methodProtected();
		}
}
