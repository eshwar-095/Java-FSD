package TestAMFromAnothPackage;

import AccessModifiers.AccessModifier;

public class Child extends AccessModifier {

	public static void main(String [] args) {
		Child obj= new Child();
		//obj.methodDefault();
		//obj.methodPrivate();
		obj.methodProtected();
		obj.methodPublic();
	}
}