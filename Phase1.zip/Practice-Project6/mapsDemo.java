package Practice;
import java.util.*;
public class mapsDemo {
	public static void main(String[]args){
		HashMap<Integer,String> a= new HashMap<Integer,String>();
		a.put(1, "MSD");
		a.put(2, "Rohit");
		a.put(3, "ABD");
		
		System.out.println("Elements of HashMap:");
		for (Map.Entry b:a.entrySet()) {
			System.out.println(b.getKey()+" "+ b.getValue());
		}
		
		System.out.println("\n");
		Hashtable<Integer,String> c= new Hashtable<Integer,String>();
		c.put(4, "Buttler");
		c.put(5, "Stokes");
		c.put(6, "Ali");
		
		System.out.println("Elements of Hashtable:");
		for (Map.Entry d:c.entrySet()) {
			System.out.println(d.getKey()+" "+ d.getValue());
		}
		
		System.out.println("\n");
		TreeMap<Integer,String> e= new TreeMap<Integer,String>();
		e.put(7, "Warner");
		e.put(8, "Smith");
		
		
		System.out.println("Elements of TreeMap:");
		for (Map.Entry f:e.entrySet()) {
			System.out.println(f.getKey()+" "+ f.getValue());
		}
	}

}
