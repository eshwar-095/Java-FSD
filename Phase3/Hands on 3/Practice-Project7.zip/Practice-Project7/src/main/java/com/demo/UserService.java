package com.demo;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	private UserRepo repo;
	
	
	public User addUser(User u) {
		return repo.save(u);
	}
	
	public List<User> getAllUser(){
		return repo.findAll();
	}
	
	public User getUserById(int id) {
		if(repo.findById(id).isPresent())
			return repo.findById(id).get();
		else
			return null;
	}
	
	public  User updateUser(int id, User User) {
		if(repo.findById(id).isPresent()) {
			User oldUser= repo.findById(id).get();
			oldUser.setName(User.getName());
			oldUser.setEmail(User.getEmail());
			oldUser.setCountry(User.getCountry());
			return repo.save(oldUser);
		}else
			return null;
	}
	
	public void deleteUser(int id) {
		  repo.deleteById(id);
	}
}
