package com.demo.JunitTest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

class ConditionalTest {

	@Test
	@EnabledOnOs({OS.WINDOWS})
	public void runOnWindows() {
		System.out.println("Run on Windows");
	}
	
	@Test
	@DisabledOnOs({OS.MAC})
	public void notRunOnMAc() {
		System.out.println("Not Run on MAC");
	}
	
	@Test
	@EnabledOnOs({OS.MAC})
	public void RunOnMAc() {
		System.out.println("Run on MAC");
	}
	
	@Test
	@EnabledOnOs({OS.LINUX})
	public void RunOnLinux() {
		System.out.println("Run on Linux");
	}
}
