package Practice;

public class MyRunnableThread implements Runnable {
	public  void run() {
		for(int i=1;i<5;i++) {
			System.out.println(i+" "+Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		MyRunnableThread a= new MyRunnableThread();
		MyRunnableThread b = new MyRunnableThread();
		
		Thread c= new Thread(a);
		Thread d= new Thread(b);
		
		c.setName("First One");
		d.setName("Second One");
		c.start();
		d.start();
	}

}
