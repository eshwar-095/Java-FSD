package Practice;

public class MyThread extends Thread{
	public void run() {
		System.out.println("Thread Began");
	}
	public static void main(String[] args) {
		MyThread a=new MyThread();
		MyThread b =new MyThread();
		a.start();
		b.start();
		
	}

}
