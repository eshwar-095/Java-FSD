package Practice;


public class constructorDemo {
	int empId;
	String empName;
	String department;
	float salary;
	
	public constructorDemo() {
		empId=1;
		empName="Def";
		department="zyx";
		salary=55000;
	}
	
	public constructorDemo(int empId,String empName,String department,float salary) {
		this.empId=empId;
		this.empName=empName;
		this.department=department;
		this.salary=salary;
	}
	
	public void display() {
		System.out.println("Id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("Department: "+department);
		System.out.println("Salary: "+salary);
		System.out.println();
		
	}
	
	public static void main(String[] args) {
		
		constructorDemo a= new constructorDemo();
		constructorDemo b= new constructorDemo(2, "Abc", "xyz", 85000); 
		a.display();
		b.display();
		
		 
	
	}
}
