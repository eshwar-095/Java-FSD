package FileHandling;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class UpdateFile {
	public static void modifyFile(String file,String oldData,String newData) {
		File Filetobemodified =new File(file);
		String Filedata="";
		BufferedReader reader=null;
		FileWriter writer = null;
		
		try {
			reader= new BufferedReader(new FileReader(Filetobemodified));
			String line=reader.readLine();
			
			while(line!=null) {
				Filedata=Filedata+line+System.lineSeparator();
				line=reader.readLine();
			}
			String NewfileData=  Filedata.replaceAll(oldData, newData);
			
			writer=new FileWriter(Filetobemodified);
			writer.write(NewfileData);
			System.out.println("Data upadated successfully");
		}catch(Exception e) {
			System.out.println("Error: "+e);
			
		}finally {
			try {
				reader.close();
				writer.close();
				System.out.println("Closed Succcessfully");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
	}
	public static void main(String[] args) {
		try {
			 modifyFile("D:\\testFile1.txt","Hi","Hello");
		}catch(Exception e) {
			System.out.println("Error: "+e);
		}
	}
}
