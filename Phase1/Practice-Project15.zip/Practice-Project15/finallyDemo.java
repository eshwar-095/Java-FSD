package Practice;

import java.util.Scanner;

public class finallyDemo {
	public static void main(String[] args) {
		Scanner a= new Scanner(System.in);
		System.out.println("Enter the first number: ");
		int b=a.nextInt();
		System.out.println("Enter the second Number: ");
		int c=a.nextInt();
		try {
			int result=b/c;
			System.out.println("Result: "+result);
		}catch(ArithmeticException e) {
			System.out.println("Error: "+e);
		}finally {
			a.close();
			System.out.println("Code completed successfully");
		}
		
	}
}
