package Practice;
class AgeNotValid extends Exception{
	private String msg;

	public AgeNotValid(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "AgeNotValid [Message= " + msg + "]";
	}
	
}



public class customHandlers {

	static void CheckAge(int age) throws AgeNotValid {
		if(age<18)
			throw new AgeNotValid("User cannot vote");
		else
			System.out.println("User can Vote");
	}
	public static void main(String[]args) {
		try {
			CheckAge(14);
		}catch(AgeNotValid e) {
			System.out.println(e);
		}
	}
}
