package Practice;

public class throwDemo {
	public static void main(String[] args) {
		int a=12;
		int b=0;
		try {
			if(b==0) {
				throw (new ArithmeticException("Divide by 0 is not applicable"));
			}else {
				int c=a/b;
				System.out.println("Result :"+c);
			}	
		}catch(ArithmeticException e){
			System.out.println("Error: "+e.getMessage());
		}
	}
}
