package Practice;

public class arraysDemo {
	public static void main(String[]args){
		int marks[]= {56,60,45,88};
		for(int i=0;i<marks.length;i++) {
			System.out.println("Individual Marks in the Array; "+marks[i]);
		}
		System.out.println("Size of the array:"+marks.length);
		System.out.println(marks[1]);
		System.out.println("\n");
		
		int matrix[][]= {{15,52,45},{15,85,69,12}};
		System.out.println("lenght of row 1: "+matrix[1].length);
		System.out.println(matrix[1][0]);
		System.out.println(matrix[0][2]);
		
	}
	
}
