package Lesson4_Assisted;



public class ArrRotation {
	public void rotate(int a[],int k) {
		if(k>a.length) {
			k=k%a.length;
			int result[]= new int[a.length];
			for(int i=0;i<k;i++) {
				result[i]=a[a.length-k+i];
			}
			int j=0;
			for(int i=k;i<a.length;i++) {
				result[i]=a[j];
				j++;
			}
			System.arraycopy(result, 0, a, 0, a.length);
		}
	}
	public static void main(String[] args) {
		ArrRotation r=new ArrRotation();
		int a[]= {1,2,5,6};
		r.rotate(a, 9);
		
		for (int i=0;i<a.length;i++) {
			System.out.print(a[i]+" ");
		}
	}

}
