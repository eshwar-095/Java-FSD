package Practice;

class AgeNotValidException extends Exception{
	private String msg;

	public AgeNotValidException(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "AgeNotValid [Message= " + msg + "]";
	}
	
}



public class exceptionHandling {

	static void CheckAge(int age) throws AgeNotValidException {
		if(age<18)
			throw new AgeNotValidException("User cannot vote");
		else
			System.out.println("User can Vote");
	}
	public static void main(String[]args) {
		try {
			CheckAge(14);
		}catch(AgeNotValidException e) {
			System.out.println(e);
		}
	}
}
