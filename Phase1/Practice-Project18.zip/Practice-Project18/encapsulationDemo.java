package Practice;
class Encapsulate{
	private String Name;
	private int Roll;
	private int Age;
	public int getAge() {
		return Age;
	}
	public String getName() {
		return Name;
	}
	public int getRoll() {
		return Roll;
	}
	public void setName(String newName) {
		Name = newName;
	}
	public void setRoll(int newRoll) {
		Roll = newRoll;
	}
	public void setAge(int newAge) {
		Age = newAge;
	}
	
	
 }
public class encapsulationDemo {
	public static void main(String[] args) {
		Encapsulate a=new Encapsulate();
		a.setName("ABC");
		a.setAge(15);
		a.setRoll(26);
		System.out.println("Name: "+a.getName());
		System.out.println("Age: "+a.getAge());
		System.out.println("Roll: "+a.getRoll());
	}
}
