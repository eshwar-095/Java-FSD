package Practice;

public class PolymorDemo {
	public int sum(int x,int y) {
		return (x+y);
	}
	public int sum(int x,int y,int z) {
		return(x+y+z);
	}
	
	public double sum(double x,double y) {
		return(x+y);
	}
	public static void main(String[] args) {
		PolymorDemo a=new PolymorDemo();
		System.out.println(a.sum(56, 44));
		System.out.println(a.sum(85, 10, 5));
		System.out.println(a.sum(5.6, 19.3));
	}
}
