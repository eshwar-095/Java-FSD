package Practice;
class Bicycle{
	public int gear;
	public int speed;
	public Bicycle(int gear, int speed) {
		this.gear = gear;
		this.speed = speed;
	}
	public void applyBrake(int decrement) {
		speed-=decrement;
	}
	public void SpeedUp(int increament) {
		speed+=increament;
	}
	@Override
	public String toString() {
		return "Bicycle"+"\n"+"No of Gears is" + gear + "\n"+"Speed of the bicycle is" + speed;
	}	
}
class mountainBike extends Bicycle{
	public int seatHeight;

	public mountainBike(int gear, int speed,int starHeight) {
		super(gear, speed);
		seatHeight=starHeight;
		
	}
	public void setHeight(int newValue) {
		seatHeight=newValue;
	}
	@Override
	public String toString() {
		return (super.toString()+"\n"+"Seat Height is"+ seatHeight);
	}
	
	
}
public class inheritanceDemo{
	public static void main(String[] args) {
		mountainBike mb= new mountainBike(5, 100, 20);
		System.out.println(mb.toString());
		
	}
	
}
