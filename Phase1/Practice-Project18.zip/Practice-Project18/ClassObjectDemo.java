package Practice;

public class ClassObjectDemo {

	 int id;
	 String name;
	 String email;
	 String password;
	 String mobile;
	 String designation;
	public ClassObjectDemo(int id, String name, String email, String password, String mobile, String designation) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.mobile = mobile;
		this.designation = designation;
	}
	
	 
	public int getId() {
		return id;
	}
	
	
	public String getName() {
		return name;
	}
	
	
	public String getEmail() {
		return email;
	}
	
	public String getPassword() {
		return password;
	}
	
	
	public String getMobile() {
		return mobile;
	}
	
	
	public String getDesignation() {
		return designation;
	}
	
	
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", email=" + email + ", password=" + password + ", mobile="
				+ mobile + ", designation=" + designation + "]";
	}
	public static void main(String[] args) {
		ClassObjectDemo a= new ClassObjectDemo(1, "ABC", "def@gmail.com", "xyz123", "8956715348", "IT");
		System.out.println(a.toString());
	}
	
}
