package Lesson4_Assisted;

import org.w3c.dom.Node;

public class SingleLinkedList {
	Node head;
	static class Node{
		int data;
		Node next;
		Node(int d){
			data=d;
			next=null;
		}
	}
	public static SingleLinkedList Insert(SingleLinkedList list,int data) {
		Node new_node=new Node(data);
		new_node.next=null;
		if(list.head==null) {
			list.head=new_node;
		}else {
			Node last=list.head;
			while(last.next!=null) {
				last=last.next;
			}
			last.next=new_node;
		}
		return list;
	}
	public static void printList(SingleLinkedList list) {
		Node currNode=list.head;
		System.out.println("Linked List:");
		while(currNode!=null) {
			System.out.print(currNode.data+" ");
			currNode=currNode.next;
		}
		System.out.println();
	}
	public static SingleLinkedList DeleteByKey(SingleLinkedList list,int key) {
		Node currNode=list.head,prev=null;
		if(currNode!=null&&currNode.data==key) {
			list.head=currNode.next;
			System.out.println(key+" found and deleted");
			return list;
		}
		while(currNode!=null&&currNode.data!= key) {
			prev=currNode;
			currNode=currNode.next;
		}
		if(currNode!=null) {
			prev.next=currNode.next;
			System.out.println(key+" found and deleted");
		}
		if(currNode==null) {
			System.out.println(key+" not found");
		}
		return list;
	}
	public static void main(String[] args) {
		SingleLinkedList list=new SingleLinkedList();
		list=Insert(list, 15);
		list=Insert(list, 25);
		list=Insert(list, 18);
		list=Insert(list, 75);
		list=Insert(list, 65);
		list=Insert(list, 17);
		list=Insert(list, 32);
		printList(list);
		DeleteByKey(list, 65);
		printList(list);
		DeleteByKey(list, 15); 
		printList(list);
		DeleteByKey(list, 1);
		printList(list);
		
	}
}
