package FileHandling;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
public class CreateWriteFile {
	public static void createFilesUsingFileClass()throws IOException{
		File a= new File("d:\\testFile1.txt");
		if (a.createNewFile()) {
			System.out.println("File Created");} 
		else {
				System.out.println("Already Exits");
			}
		FileWriter b = new FileWriter(a,false);
		b.write("hello there !");
		b.close();
		
	}
	public static void createFilesUsingOutputStream()throws IOException{
		FileOutputStream c= new FileOutputStream("d:\\test2.txt");
		String d="Hi there !";
		byte array[]=d.getBytes();
		c.write(array);
		System.out.println("Test2 written successfullly");
		c.close();
	}
	public static void createFileusingNIO()throws IOException{
		Path e= Paths.get("d:\\test3.txt");
		String f="I am Fine";
		byte array[]=f.getBytes();
		Files.write(e, array, StandardOpenOption.CREATE,StandardOpenOption.APPEND);
		System.out.println("Test3 written successfully");
	}
	
	
	
	
	
	public static void main(String[] args) {
		try {
			createFilesUsingFileClass();
			createFilesUsingOutputStream();
			createFileusingNIO();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}
