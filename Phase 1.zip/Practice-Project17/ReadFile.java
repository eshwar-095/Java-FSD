package FileHandling;

import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ReadFile {
	public static void readFileusingFileClass()throws IOException{
		FileReader a= new FileReader("D:\\testFile1.txt");
		int data;
		while((data= a.read())!=-1) {
			System.out.print((char)data);
		}
	}
	public static void readFileusingFileinputStream()throws IOException {
		FileInputStream b= new FileInputStream("D:\\test2.txt");
		int data1;
		while((data1=b.read())!=-1) {
			System.out.print((char)data1);
		}
	}
	public static void readFileuisngNIO()throws IOException{
		List<String> list=Collections.emptyList();
		Path paths = Paths.get("D:\\test3.txt");
		list=Files.readAllLines(paths,StandardCharsets.UTF_8);
		
		Iterator<String> itr = list.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}
	
	public static void main(String[] args) {
		try {
			//readFileusingFileClass();
			//readFileusingFileinputStream();
			readFileuisngNIO();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
