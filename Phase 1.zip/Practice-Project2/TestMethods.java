package AccessModifiers;

public class TestMethods {
			public static void main(String [] args) {
				
		AccessModifier obj= new  AccessModifier();
				
				obj.methodDefault();
				//obj.methodPrivate(); 
				obj.methodProtected();
				obj.methodPublic();
			}
}
