package Practice;



public class tryCatch {
	public static void main(String[] args) {
		int a=12;
		int b=0;
		try{
			int c=a/b;
		}catch (ArithmeticException e) {
			System.out.println("Error: "+e);
		}
		
	}
}
