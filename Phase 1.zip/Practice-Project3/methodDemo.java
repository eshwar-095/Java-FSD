package Practice;


public class methodDemo {
	public void print() {
		System.out.println("Method without return type and without parameter");
	}
	
	public void display(String name) {
		
		System.out.println("My name is "+name);
	}
	
	public int add(int n1,int n2) {
		return n1+n2;
	}
	
	public String fullName(String fname, String lname) {
		return fname+" "+lname;
	}
	
	public static void main(String[] args) {
		
		methodDemo obj= new methodDemo();
		obj.print();
		obj.display("ABC");
		
		int add=obj.add(45,89);
		System.out.println("addition of n1 and n2 is : "+add);
		
		String MyName=obj.fullName("ABE", "DEF");
		System.out.println("My Name is: "+MyName);
		
		
	}
}
