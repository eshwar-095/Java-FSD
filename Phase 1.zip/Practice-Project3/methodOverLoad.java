package Practice;

public class methodOverLoad {
	int add(int a, int b) {
		return a+b;
	}
	int add(int a, int b,int c) {
		return a+b+c;
	}
	float add(float a, float b) {
		return a+b;
	}
	
	double add(double a, double b) {
		return a+b;
	}
	
	 
	
	public static void main(String[] args) {
		methodOverLoad obj= new  methodOverLoad();
		System.out.println("Addition of 45 and 89 :"+obj.add(45, 89));
		System.out.println("Addition of 45.0 and 89.25 :"+obj.add(45.0f,89.25f));
		System.out.println("Addition of 2 double :"+obj.add(4.5, 8.9));
		System.out.println("Addition of 3 int: "+obj.add(40, 60, 0));
		
	}
}
