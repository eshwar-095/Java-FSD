package Practice;

public class callByValue {
	
	int num=100;
	void operation(int num) {
		this.num=(num*15)/2;
		
	}
	public static void main(String[] args) {
		
		callByValue a= new callByValue();
		
		System.out.println("Value of num before function call: "+a.num);
		
		a.operation(50);
		System.out.println("Value of num after function call: "+a.num);
	}
}
