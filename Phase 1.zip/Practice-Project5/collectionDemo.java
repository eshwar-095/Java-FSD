package Practice;
import java.util.*;
public class collectionDemo {
	public static void main(String[]args) {
		System.out.println("ArrayList Implementation: ");
		ArrayList<String> car = new ArrayList<String>();
		car.add("BMW");
		car.add("HondaCity");
		System.out.println(car);
		
		Iterator<String> itr = car.iterator();
		while(itr.hasNext()) {
			System.out.println("Using Iterator: "+ itr.next());
		}
		
		System.out.println("\n");
			System.out.println("Vector Implementation: ");
			Vector<Integer> abc = new Vector<Integer>();
			abc.add(52);
			abc.add(96);
			System.out.println(abc);
			for(int a : abc) {
				System.out.println("Using For loop; " + a);
			}
		System.out.println("\n");
			System.out.println("LinkedList Implementation: ");
			LinkedList<String> sports = new LinkedList<String>();
			sports.add("Cricket");
			sports.add("Football");
			System.out.println(sports);
			
			Iterator<String> itr1 = sports.iterator();
			while(itr1.hasNext()) {
				System.out.println("Using Iterator: "+ itr1.next());
			}
		
		System.out.println("\n");
			System.out.println("PriorityQueue Implementation: ");
			PriorityQueue<Integer> pQueue= new PriorityQueue<Integer>(); 
			pQueue.add(5);
			pQueue.add(56);
			pQueue.add(67);
			pQueue.add(89);
			pQueue.add(1);
			System.out.println(pQueue);
		
		System.out.println("\n");
	       System.out.println("HashSet Implementation");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(101);  
	       set.add(103);  
	       set.add(102);
	       set.add(104);
	       System.out.println(set);
	       
	    System.out.println("\n");
	       System.out.println("LinkedHashSet Implemenattion");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(11);  
	       set2.add(13);  
	       set2.add(12);
	       set2.add(14);	       
	       System.out.println(set2);
	      	
		System.out.println("\n");
	       System.out.println("TreeSet Implemenattion");
	       Set<String> set3 = new TreeSet<String>(); 
	       set3.add("Banana");
	       set3.add("Cherry");
	       set3.add("Almond");
	       set3.add("Apple");
	       System.out.println(set3);
		}
	}
