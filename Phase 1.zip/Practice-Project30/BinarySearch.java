package SearchingAlg;

public class BinarySearch {
	public static void main(String[] args) {
		int arr[]= {11,12,56,85,95,147};
		int key=148;
		int Length=arr.length;
		BinaryMethod(arr,0,key,Length);
	}

	private static void BinaryMethod(int[] arr, int lower, int key, int higher) {
		int Mid=(lower+higher)/2;
		while(lower<=higher) {
			if(arr[Mid]==key) {
				System.out.println("Element found at index: "+Mid);
				break;
			}else if(arr[Mid]<key) {
				lower=Mid+1;
			}else {
				higher=Mid-1;
			}
			Mid=(lower+higher)/2;
		}
		 if(lower>higher) {
	            System.out.println("Element Not Found");
		
	}
	}
}