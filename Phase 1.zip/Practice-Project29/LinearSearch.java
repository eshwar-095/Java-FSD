package SearchingAlg;

import java.util.Scanner;

public class LinearSearch {
	public static void main(String[] args) {
		int a[]= {15,84,56,78,25,36};
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the element to be searched: ");
		int SearchValue = sc.nextInt();
		int Result =LinearMethod(a,SearchValue);
		if(Result==-1) {
			System.out.println("Element Not Found");
		}else {
			System.out.println("Element Found at index:["+Result+"],and Search Key is :"+a[Result]);
		}
		
	}
	private static int LinearMethod(int arr[],int SearchValue) {
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==SearchValue) {
				return i;
			}
		}
		return -1;
	}
}
