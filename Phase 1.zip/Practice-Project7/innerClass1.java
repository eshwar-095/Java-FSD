package Practice;

public class innerClass1 {
	private String a="Hello there !";
	
	void display(){
		class Inner {
			void msg() {
				System.out.println(a);
			}
		}
		Inner b = new Inner();
		b.msg();
	}
	public static void main(String[]args) {
		innerClass1 c = new innerClass1();
		c.display();
	}
}
