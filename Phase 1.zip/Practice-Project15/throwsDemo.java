package Practice;

public class throwsDemo {
	static void checkAge(int age)throws Exception {
		if (age<18) 
			System.out.println("Invalid");
			else 
			System.out.println("Valid");
	}
	static void test()throws Exception{
		checkAge(19);
	}
	public static void main(String[]args) {
		try {
			test();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}

