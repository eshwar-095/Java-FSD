package Lesson4_Assisted;


public class stackDemo {
	static final int MAX=1000;
	int top;
	int a[]=new int[MAX];
	
	boolean isEmpty() {
		return top<0;
	}
	public stackDemo(){
		top = -1;
	}
	boolean push(int x) {
		if(top>=(MAX-1)) {
			System.out.println("Stack overflowing");
			return false;
		}else {
			a[++top]=x;
			System.out.println(x+" Pushed into stack");
			return true;
		}
	}
	int pop() {
		if(top<0) {
			System.out.println("Stack underflowing");
			return 0;
		}else {
			int x=a[top--];
			return x;
		}
	}
	  int peek() {
		if(top<0) {
			System.out.println("Stack underflowing");
			return 0;
		}else {
			int x=a[top];
			return x;
		}
	
	}
	public static void main(String[] args) {
		stackDemo a =new stackDemo();
		a.push(25);
		a.push(52);
		a.push(55);
		a.push(15);
		a.push(7);
		System.out.println(a.pop()+": Poped out from the stack");
		System.out.println(a.peek()+": Top of the stack");
	}
}
