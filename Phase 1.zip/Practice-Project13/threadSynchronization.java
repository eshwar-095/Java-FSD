package Practice;
class User extends Thread{
	String Name;
	String Msg;
	Sender sender;
	public User(String name, String msg, Sender sender) {
		this.Name = name;
		this.Msg = msg;
		this.sender = sender;
	}
	public void run() {
		System.out.println(Name +" wants to send a message: "+Msg);
		synchronized (sender) {
			sender.send(Msg);
		}
		
	}	
}
 class Sender{
	void send(String Msg) {
		System.out.println("Sending msg..."+Msg);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error occured: "+e);
		}
		System.out.println("Messsage sent Successdully");
	}
}
public class threadSynchronization {
	public static void main(String[] args) {
		Sender sender= new Sender();
		User a = new User("ABC", "Hello There!", sender);
		User b = new User("EFG", "Hi,How are you?", sender);
		a.start();
		b.start();
	}

}
