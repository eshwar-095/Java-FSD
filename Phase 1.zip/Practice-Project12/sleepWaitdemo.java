package Practice;

public class sleepWaitdemo {
	private static Object LOCK=new Object();
	public static void main(String[] args) {
		try {
			Thread.sleep(1000);
			System.out.println(Thread.currentThread().getName()+" woke up after 1 second of sleep");
		synchronized(LOCK) {
			LOCK.wait(2000);
			System.out.println("Object "+LOCK+" woke up after wait of 2 seconds");
		}
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
}
