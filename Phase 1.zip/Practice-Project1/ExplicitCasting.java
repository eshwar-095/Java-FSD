package TypeCasting;

public class ExplicitCasting {
	public static void main(String[] args) {

		double a= 23.67;
		
		int b=(int) a;  
		
		System.out.println("Converted Double "+a+" to int "+b);
		
	}
}
