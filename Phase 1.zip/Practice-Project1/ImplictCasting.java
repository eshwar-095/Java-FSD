package TypeCasting;

public class ImplictCasting {
	public static void main(String[]args) {
		byte a =10;
		System.out.println("Byte: "+a);
		
		short b =a;
		System.out.println("Byte to Short: "+b);
		
		int c=b;
		System.out.println("Short to Int: "+c);
		
		int d=a;
		System.out.println("Byte to Int: "+d);
		
		float e=a;
		System.out.println("Byte to Float: "+e);
		
		double f =a;
		System.out.println("Byte to Double: "+f);
		
		double g = c;
		System.out.println("Int to  Double: "+g);
		
		
		
	}
}
