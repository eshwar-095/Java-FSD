package Practice;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regularExpnDemo {
	public static void main(String[]args) {
		String pattern ="[a-z]+";
		String Check="Hello There";
		Pattern a= Pattern.compile(pattern);
		Matcher b =a.matcher(Check);
		while(b.find()) {
			System.out.println(Check.substring(b.start(), b.end()));
		}
		
	}
}
