import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataService } from './data.service';
import { RegisterComponent } from './register/register.component';
import { ServiceComponent } from './service/service.component';
import { DirectiveComponent } from './directive/directive.component';
import { ChangeColorDirective } from './ChangeColorDirective';
import { HighLightDirective } from './HighlightDirective';
import { Directive2Component } from './directive2/directive2.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    ServiceComponent,
    DirectiveComponent,
    ChangeColorDirective,
    HighLightDirective,
    Directive2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
  
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
