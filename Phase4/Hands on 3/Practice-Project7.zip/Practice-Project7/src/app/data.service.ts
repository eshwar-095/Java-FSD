import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }

  getUSer(){
    return {"fname": "ABCD","lname":"MR."};
  }
}
