import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  name:string="Hi There ! How are you ?";
  pi:number=3.141548;
  a=0.256841;
  b=85746.254697;
  today=new Date();
  object={name:"ABC",email:"abc@gmail.com",location:"XYZ"};

  cust:string="Welcome to the world of customPipes";
}

